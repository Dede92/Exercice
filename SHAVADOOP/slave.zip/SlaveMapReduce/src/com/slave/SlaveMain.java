package com.slave;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;

public class SlaveMain {

	private static String address;
	
	private static String filePath;
	
	private static String PATH = "/cal/homes/dho/MapperSHAVADOOP/";
	
	public static void main(String[] args) {
		new SlaveMain(args);
	}
	
	public SlaveMain(String[] args) {
		try {
			whoIAm();
			Thread.sleep(5000);
			List<String> temp = new ArrayList<String>();
			for(String arg: args) {
				temp.add(arg);
			}
			String param = temp.get(0);
			temp.remove(0);
			
			if(param.equals("mapper")){
				String[] array = new String[temp.size()];
				for(int i = 0; i < temp.size(); i++){
					array[i] = temp.get(i);
				}
				maping(array);
				System.out.println(address + ":" + printOutput(array));
			}else if(param.equals("reducer")){
				List<String> temp2 = new ArrayList<String>();
				for(String arg: temp) {
					temp2.add(arg);
				}
				String key = temp2.get(0);
				temp2.remove(0);
				
				int occurence = 0;
				
				for(String t: temp2) {
					List<String> test = ReaderF.splitFile(PATH + t + ".txt");
					for(String tr: test){
						String[] keys = tr.split("\\s+");

						if(key.equals(keys[0])){
							occurence += Integer.parseInt(keys[1]);
						}
					}
				}
				System.out.println(key + ": " + occurence);
			}
			
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	//trouve le nom de la machine
	public void whoIAm() throws IOException {
		ProcessBuilder pb = new ProcessBuilder("sh", "-c", "hostname -i");
		
        Process process = pb.start();
        
		BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
		String line = "";
		try {
			while((line = reader.readLine()) != null) {
				address = line;
				filePath = PATH + address + ".txt";
			}
		} finally {
			reader.close();
		}
	}
	
	public void maping(String[] args) {
		for(int i = 0 ; i < args.length ; i++) {
			Writer.writer(filePath, args[i] + " 1");
		}
	}
	
	public String printOutput(String[] args) {
		StringBuilder builder = new StringBuilder();
		for(int i = 0 ; i < args.length; i++) {
		    if(i != args.length -1) {
		    	builder.append(args[i] + " ");
		    } else {
		    	builder.append(args[i]);
		    }
		}
		String s = builder.toString();
		return new LinkedHashSet<String>(Arrays.asList(s.split(" "))).toString().replaceAll("(^\\[|\\]$)", "").replace(", ", " ");
	}
	
	

}
