package com.slave;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ReaderF {


	public static BufferedReader readFile(String filePath) throws IOException
	{
		BufferedReader lecteurAvecBuffer = null;
		lecteurAvecBuffer = new BufferedReader(new FileReader(filePath));

		return lecteurAvecBuffer;
	}

	public static List<String> splitFile(String filePath) throws IOException {
		BufferedReader lecteurAvecBuffer = readFile(filePath);
		String ligne ="";
		List<String> splitText = new ArrayList<String>();
		while ((ligne = lecteurAvecBuffer.readLine()) != null) {
			splitText.add(ligne);
		}
		
		return splitText;
	}

}
