package com.master;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class SSHMethod {

	/**
	 * @param args
	 * @throws IOException 
	 * @throws InterruptedException 
	 */
	public static boolean sshPing(String ipAdress) throws IOException, InterruptedException {
		Runtime runtime = Runtime.getRuntime();
		String[] cmdline = { "ssh", ipAdress, "echo OK" };
		boolean boolSSH = false;

		Process process = runtime.exec(cmdline);
		process.waitFor();
		BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
		String line = "";
		try {
			while((line = reader.readLine()) != null) {
				if(line.equals("OK"))
					boolSSH = true;

			}
		} finally {
			reader.close();
		}
		return boolSSH;
	}

	public static Process sshJar(String ipAdress) throws IOException {
		Runtime runtime = Runtime.getRuntime();
		String[] cmdline = { "ssh", ipAdress, "java -jar","/cal/homes/dho/slavejar.jar" };

		Process process = runtime.exec(cmdline);

		BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
		String line = "";
		try {
			while((line = reader.readLine()) != null) {
				System.out.println(line);
			}
		} finally {
			reader.close();
		}
		return process;
	}
	
	public static void sshJarProcessBuilder(String ipAdress, String arg) throws IOException, InterruptedException {
		ProcessBuilder pb = new ProcessBuilder("ssh", ipAdress, "java -jar","/cal/homes/dho/slavejar.jar " + arg);
		
        Process process = pb.start();
        
        DisplayStream inputStream = new DisplayStream(process.getInputStream());
        DisplayStream errorStream = new DisplayStream(process.getErrorStream());
        
        new Thread(inputStream).start();
        new Thread(errorStream).start();
        
        process.waitFor();
	}

}
