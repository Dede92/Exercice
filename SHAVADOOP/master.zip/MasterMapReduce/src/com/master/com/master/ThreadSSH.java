package com.master;

public class ThreadSSH extends Thread{
	public ThreadSSH(RunnableSSH runnable){
	    super(runnable);
	  }
}
