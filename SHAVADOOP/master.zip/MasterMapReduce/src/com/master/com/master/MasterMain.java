package com.master;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.file.ReaderF;
import com.file.Writer;

public class MasterMain {

	public String filePath = "/cal/homes/dho/mapReduce.txt";

	public String availableFilePath = "/cal/homes/dho/hostAvailable.txt";

	public String inputText = "/cal/homes/dho/input2.txt";

	public List<String> splitText ;

	public List<String> availableHosts;

	// UMx - Machines: UMX est le numéro du split, machine est le numéro du slave
	public static Map <String, String> d1;
	// clés - UMx
	public static Map <String, List<String>> d2;
	//RMx-machine
	public static Map <String, String> d3;

	public MasterMain() {
		// find every machine turned on
		//		findMachine();

		d2 = new HashMap<String, List<String>>();
		try {
			splitText = ReaderF.splitFile(inputText);
			availableHosts = ReaderF.splitFile(availableFilePath);
		} catch (IOException e1) {
			e1.printStackTrace();
		}

		System.out.println(splitText);

		List<Thread> threadList = new ArrayList<Thread>();


		for( int i = 0 ; i < splitText.size() ; i++) {
			System.out.println("Mapping Slave launched: " + availableHosts.get(i) + " " + "Split given: " + splitText.get(i));
			RunnableSSH runnableSSH = new RunnableSSH(availableHosts.get(i),  "mapper " + splitText.get(i));

			Thread t = new Thread(runnableSSH);
			t.start();
			threadList.add(t);
		}

		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		PrintStream ps = new PrintStream(baos);
		// IMPORTANT: Save the old System.out!
		PrintStream old = System.out;
		// Tell Java to use your special stream
		System.setOut(ps);


		for(Thread t: threadList){
			try {
				t.join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		// Redirect to the console
		System.out.flush();
		System.setOut(old);
		
//		System.out.println(baos.toString());

		readSlave(baos.toString());

		System.out.println("Mapping Slaves are done \n");
		
		
		int i = 0;
		for(Entry<String, List<String>> entry: d2.entrySet()){
//			System.out.println(entry.getKey() + ": " + entry.getValue());
			
			System.out.println("Reducing Slave launched: " + availableHosts.get(i) + " " + "key: " + entry.getKey());
			
			String listString = "";
			for (String s : entry.getValue())
			{
			    listString += s + "\t";
			}
			
			RunnableSSH runnableSSH = new RunnableSSH(availableHosts.get(i),  "reducer " + entry.getKey() + " " + listString);
			
			i++;
			
			Thread t = new Thread(runnableSSH);
			t.start();
			threadList.add(t);
		}
		
		baos = new ByteArrayOutputStream();
		ps = new PrintStream(baos);
		// IMPORTANT: Save the old System.out!
		old = System.out;
		// Tell Java to use your special stream
		System.setOut(ps);
		
		for(Thread t: threadList){
			try {
				t.join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		// Redirect to the console
		System.out.flush();
		System.setOut(old);
		Map<String, String> output = finalOutput(baos.toString());
		for(Entry<String,String> entry: output.entrySet()){
			System.out.println(entry.getKey() + " " + entry.getValue());
		}
		System.out.println("Reducing Slaves are done \n");
		
	}

	public void findMachine() {
		try {
			BufferedReader lecteurAvecBuffer = ReaderF.readFile(filePath);
			String ligne;
			int i = 0;
			while ((ligne = lecteurAvecBuffer.readLine()) != null) {
				boolean hostAvailable = SSHMethod.sshPing(ligne);
				if(hostAvailable) {
					Writer.writer(availableFilePath, ligne);
					i++;
				}
			}
			System.out.println("Number of available computers: " + i);

			lecteurAvecBuffer.close();

		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

//	public void firstMethod() {
//		try {
//			BufferedReader lecteurAvecBuffer;
//			lecteurAvecBuffer = ReaderF.readFile(availableFilePath);
//			String ligne;
//			while ((ligne = lecteurAvecBuffer.readLine()) != null) {
//				System.out.println("Slave launched: " + ligne);
//				ThreadSSH threadSSH = new ThreadSSH(ligne);
//				Thread t = new Thread(threadSSH);
//				t.start();
//				threadList.add(t);
//			}
//			lecteurAvecBuffer.close();
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
//	}

	private void readSlave(String stream){
		String[] splits = stream.split("\\r?\\n");
		for(String split: splits){
			makeDico(split);
		}
	}

	private void makeDico(String rawKey) {
		String[] splits = rawKey.split(":");
		String[] keySplits = splits[1].split("\\s+");

		for(String key: keySplits){
			if(d2.get(key) == null){
				List<String> tempList = new ArrayList<String>();
				tempList.add(splits[0]);
				d2.put(key, tempList);
			} else {
				d2.get(key).add(splits[0]);
			}
		}
	}
	
	private Map<String, String> finalOutput(String rawOutput){
		Map<String, String> map = new HashMap<String, String>();
		String[] splits = rawOutput.split("\\r?\\n");
		
		for(String string: splits) {
			String[] keyValue = string.split(":");
			map.put(keyValue[0].replaceAll("\\s+",""), keyValue[1]);
		}
		
		
		return map;
	}

	public static void main(String[] args) {
		new MasterMain();
	}

}
