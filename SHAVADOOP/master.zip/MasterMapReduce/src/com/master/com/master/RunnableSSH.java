package com.master;

import java.io.IOException;

public class RunnableSSH implements Runnable {

	private String ipAdress;
	
	private String ligne;
	
	public RunnableSSH (String ipAdress, String ligne) {
		this.ipAdress = ipAdress;
		this.ligne = ligne;
	}
	
	@Override
	public void run() {
		try {
			SSHMethod.sshJarProcessBuilder(ipAdress, ligne);
			
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}
